
# Load the required libraries
library(png)
library(grid)

# Define the image file path
image_path <- "C:\\Users\\USER\\Netflix Data Visualization\\Most Watched Genres on Netflix.png"

# Step 1: Check if the image file exists
if (file.exists(image_path)) {
  # Step 2: Read and display the image if it exists
  img <- readPNG(image_path)
  grid.raster(img)  # Display the image using grid.raster
} else {
  # Step 3: If the file doesn't exist, print an error message
  cat("Error: The image file does not exist at the specified path:", image_path, "\n")
}


